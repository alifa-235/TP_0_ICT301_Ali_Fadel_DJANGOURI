public class MainOld {
    public static void main(String[] args) {
        OrderProcessor order = new OrderProcessor();
        order.processOrder("Order 123");
    }
}