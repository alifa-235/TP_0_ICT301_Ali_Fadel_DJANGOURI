public interface Database {
    void save(String data);
}